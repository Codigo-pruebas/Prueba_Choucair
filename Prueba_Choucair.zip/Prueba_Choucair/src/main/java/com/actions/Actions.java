package com.actions;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;


import org.apache.commons.io.FileUtils;
import org.apache.xmlbeans.impl.regex.REUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.codigo.Cls_Cross_Browsing;
import com.codigo.Cls_Log_Ejecucion;


public class Actions {

	WebDriver driver;
	JavascriptExecutor jse;
	public SimpleDateFormat Dt_Fecha, Dt_FechaCarpeta;
	public File Obj_Archivo;
	public File Obj_Carpeta;
	public String Str_Nombre_Archivo = "";
	public String Str_Fecha = "";
	public String Str_Ruta = "";
	public String Str_Error = "";
	public String Str_Ruta_ScreenShot = "";
	public String Str_lane = "_";
	public String Str_folder = "Evidencia de Ejecucion";
	public String Str_Exitoso = "Casos_Exitosos_";
	public String Str_Fallido = "Casos_Fallidos_";
	public String Str_Elemento = "";
	public String Str_Ruta2 = "";
	public String className;
	Cls_Cross_Browsing Obj_Cross_Browsing;
	Cls_Log_Ejecucion Obj_Log_Ejecucion;

	public Actions(WebDriver driver) {
		this.driver = driver;
	}

	//	public Cls_Cross_Browsing CrossBrowsing() {
	//		this.driver = CrossBrowsing().get_Obj_Driver();
	//		return Obj_Cross_Browsing;
	//	}

	public void set_Driver(WebDriver driver)
	{
		this.driver = driver;
	}

	public void maximizarVentana() {
		driver.manage().window().maximize();
	}

	public void salirNavegador(boolean status) {
		if(status=true){
			ResultSuccess();			
		}else{
			ResultFail();	
		}
		driver.quit();
	}


	/**
	 * Carga una nueva p�gina web en la ventana actual del navegador.
	 *
	 * @param url
	 */
	public boolean abrirUrl(String url) {
		try{
			driver.navigate().to(url);
			ResultSuccess();
		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00001: Error abriendo la URL: "+ url +" en el navegador" + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		System.out.println("Informacion: Elemento "+ url + " clickeado por XPATH");
		return true;
	}


	//Metodos para realizar Click
	public boolean clickByXpath(String elemento, String nombreElemento) {
		this.Str_Elemento = elemento;
		try{
			
			driver.findElement(By.xpath(elemento)).click();
			Str_Error="Clickeado elemento por XPATH ="+ nombreElemento;
			//Mensaje por consola indicando que se ha hecho clic en el elemento
			System.out.println("Informacion: Elemento "+ elemento + " clickeado por XPATH");
			ResultSuccess();
			return true;
			
		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00002: Error clickeando elemento "+ elemento +" por XPATH = "+ nombreElemento;// + Obj_Excepcion.getMessage();
			Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
			Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,elemento);
			Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,elemento);
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}

	}


	public boolean clickByLink(String elemento, String nombreElemento) {
		this.Str_Elemento = elemento;
		try{
			ResultSuccess();
			driver.findElement(By.linkText(elemento)).click();
			Str_Error="Clickeado elemento por Id = "+nombreElemento;
			//Mensaje por consola indicando que se ha hecho clic en el elemento
			Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
			Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,elemento);
			Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,elemento);
			System.out.println("Informacion: Elemento "+ elemento + " clickeado por link");
			return true;
		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00005: Error clickeando elemento "+ elemento +" por link"+nombreElemento;// + Obj_Excepcion.getMessage();
			Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
			Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,elemento);
			Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,elemento);
			System.out.println(Str_Error);
			ResultFail();			
			return false;
		}
	
	}


	//ESCRIBIR 
	public boolean TypeByXpath(String elemento, String text, String nombre) {
		this.Str_Elemento = elemento;
		try{
			System.out.println("driver: "+driver);
			driver.findElement(By.xpath(elemento)).sendKeys(text);
			Str_Error="Escribiendo elemento por Xpath =";
			//Mensaje por consola y log indicando que se ha escrito en el elemento
			System.out.println("Informacion: Elemento "+ elemento + " escribiendo por XPATH" +nombre);
			ResultSuccess();
			return true;
			
		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00010: Error escribiendo en el elemento "+ elemento +" por XPATH " + nombre;// + Obj_Excepcion.getMessage();
			Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
			Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,elemento);
			Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,elemento);
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}

	}

	

	public boolean TypeByName(String elemento, String text) {
		this.Str_Elemento = elemento;
		try{
			driver.findElement(By.name(elemento)).sendKeys(text);
		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00012: Error escribiendo en el elemento "+ elemento +" por NAME  , " + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		System.out.println("Informacion: Elemento "+ elemento + " clickeado por NAME");
		return true;
	}

	public boolean TypeByID(String elemento, String text, String nombreElemento)  {
		this.Str_Elemento = elemento;
		try{
			driver.findElement(By.id(elemento)).sendKeys(text);
			Str_Error="Escribiendo elemento por ID ="+nombreElemento ;
		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00013: Error escribiendo en el elemento "+ elemento +" por ID"+ nombreElemento;// + Obj_Excepcion.getMessage();
			Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
			Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,elemento);
			Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,elemento);
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
		Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,elemento);
		Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,elemento);
		System.out.println("Informacion: Elemento "+ elemento + " Escribiendo por ID");
		return true;
	}

	
	//ESPERAR POR ...

	public void esperarSegundos(int segundos)
	{
		synchronized(driver){
			try {
				driver.wait(segundos * 1000);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	//Javascript
	public void ForzarClickJavascript(WebDriver driver, String Xpath){
		WebElement element = driver.findElement(By.xpath(Xpath));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	}
	
	


	
	public void ForzarTypeJavascriptId(WebDriver driver,String id, String value, String nombreCampo) {
		
	try {
		WebElement element = driver.findElement(By.id(id));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].value='"+value+"'" , element);
		Str_Error="Escribiendo Javascript elemento por xpath =" + nombreCampo;
		//Mensaje por consola indicando que se ha escrito en el elemento
		System.out.println("Informacion: Elemento "+ id + " clicleado por id");
		
	}catch(Exception Obj_Excepcion)
	{
		ResultFail();
		Str_Error = "Error 00090: Error Elemento: "+id+" escribiendo Javascript" + nombreCampo;// + Obj_Excepcion.getMessage();
		Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
		Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,id);
		Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,id);
		System.out.println(Str_Error);
		
	}

	
	}


	//Capturas de pantalla
	public static void GenerarCaptura(WebDriver webdriver,String fileWithPath) throws Exception{

		TakesScreenshot scrShot =((TakesScreenshot)webdriver);

		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

		File DestFile=new File(fileWithPath);

		FileUtils.copyFile(SrcFile, DestFile);

	}

	public boolean ResultSuccess(){	
		try{		
			Dt_Fecha = new SimpleDateFormat("dd-M-yyyy");
			Dt_FechaCarpeta = new SimpleDateFormat("h:mm a");
			Str_Ruta = Dt_Fecha.format(new Date()) +"\\";
			Str_Ruta = Str_Ruta.replaceAll("-", "_");
			Str_Ruta2 = Str_Exitoso+className;
			Obj_Carpeta = new File(Str_folder, Str_Ruta+Str_Ruta2);
			if (!Obj_Carpeta.isDirectory())
			{
				Obj_Carpeta.mkdirs();
			}
			File srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			Dt_Fecha = new SimpleDateFormat("dd-M-yyyy hh:mm:ss mmm");	
			Str_Nombre_Archivo = className + Str_lane + Dt_Fecha.format(new Date());
			Str_Nombre_Archivo = Str_Nombre_Archivo.replaceAll(":", "_");
			Str_Nombre_Archivo = Str_Nombre_Archivo.replaceAll("-", "_");
			FileUtils.copyFile(srcFile, new File (Obj_Carpeta, Str_Nombre_Archivo + ".jpg"));
			Str_Nombre_Archivo = "";
		}
		catch(IOException e){
			e.printStackTrace();
			CloseCapture();
			return false;
		}
		return false;
	}

	public boolean ResultFail(){

		try{		
			Dt_Fecha = new SimpleDateFormat("dd-M-yyyy");
			Str_Ruta = Dt_Fecha.format(new Date()) +"\\";
			Str_Ruta = Str_Ruta.replaceAll("-", "_");
			Str_Ruta2 = Str_Fallido+className;
			Obj_Carpeta = new File(Str_folder, Str_Ruta+Str_Ruta2);
			if (!Obj_Carpeta.isDirectory())
			{
				Obj_Carpeta.mkdirs();
			}
			File srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			Dt_Fecha = new SimpleDateFormat("dd-M-yyyy hh:mm:ss mmm");	
			Str_Nombre_Archivo = className + Str_lane + Dt_Fecha.format(new Date());
			Str_Nombre_Archivo = Str_Nombre_Archivo.replaceAll(":", "_");
			Str_Nombre_Archivo = Str_Nombre_Archivo.replaceAll("-", "_");
			FileUtils.copyFile(srcFile, new File (Obj_Carpeta, Str_Nombre_Archivo + ".jpg"));
			Str_Nombre_Archivo = "";
		}
		catch(IOException e){
			e.printStackTrace();
			CloseCapture();
			return false;
		}
		return false;
	}

	public void TakeScreenshot(WebDriver webdriver) throws Exception{
		try{
			ResultSuccess();
		}catch(Exception Obj_Excepcion)
		{
			ResultFail();
			Str_Error = "Error 00068: No se pudo tomar la captura de pantalla" + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
		}
	}

	//Salir driver
	private void CloseCapture()
	{
		try
		{
			driver.close();
		}
		catch(Exception Obj_Excepcion)
		{
			Str_Error = "Error (?????): " + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
		}
	}


	//DROPDOWN
	public boolean SelectDropDownVALUEByXpath(WebDriver driver, String xpathElemento, String SeleccionarElementoDropdown, String nombreElemento)  {

		try{
			Select selection = new Select(driver.findElement(By.xpath(xpathElemento)));
			selection.selectByValue(SeleccionarElementoDropdown);
			Str_Error="Seleccionando elemento por XPATH ="+ nombreElemento;

		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00034: No se pudo seleccionar el elemento del dropdown"+ nombreElemento;// + Obj_Excepcion.getMessage();
			Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
			Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,xpathElemento);
			Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,xpathElemento);
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
		Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,xpathElemento);
		Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,xpathElemento);
		System.out.println("Informacion: Elemento "+ xpathElemento+ "seleccionado correctamente");
		return true;
	}

	public boolean SelectDropDownINDEXByXpath(WebDriver driver, String xpathElemento, int SeleccionarElementoDropdown )  {

		try{
			Select selection = new Select(driver.findElement(By.xpath(xpathElemento)));
			selection.selectByIndex(SeleccionarElementoDropdown);

		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00035: No se pudo seleccionar el elemento del dropdown" + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		System.out.println("Informacion: Elemento seleccionado correctamente");
		return true;
	}

	public boolean SelectDropDownTEXTByXpath(WebDriver driver, String xpathElemento, String SeleccionarElementoDropdown, String nombreElemento )  {

		try{
			Select selection = new Select(driver.findElement(By.xpath(xpathElemento)));
			selection.selectByVisibleText(SeleccionarElementoDropdown);
			ResultSuccess();

		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00036: No se pudo seleccionar el elemento del dropdown";
			System.out.println(Str_Error);
			Obj_Log_Ejecucion = new Cls_Log_Ejecucion();
			Obj_Log_Ejecucion.Registrar_Log_TXT(Str_Error,nombreElemento);
			Obj_Log_Ejecucion.Registrar_Log_HTML(Str_Error,nombreElemento);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		System.out.println("Informacion: Elemento seleccionado correctamente");
		return true;
	}

	public boolean SelectDropDownVALUEByID(WebDriver driver, String idElemento, String SeleccionarElementoDropdown )  {

		try{
			Select selection = new Select(driver.findElement(By.id(idElemento)));
			selection.selectByValue(SeleccionarElementoDropdown);

		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error = "Error 00037: No se pudo seleccionar el elemento del dropdown" + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		System.out.println("Informacion: Elemento seleccionado correctamente");
		return true;
	}

	public boolean SelectDropDownINDEXByID(WebDriver driver, String idElemento, int SeleccionarElementoDropdown )  {

		try{
			Select selection = new Select(driver.findElement(By.id(idElemento)));
			selection.selectByIndex(SeleccionarElementoDropdown);

		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00038: No se pudo seleccionar el elemento del dropdown" + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		System.out.println("Informacion: Elemento seleccionado correctamente");
		return true;
	}

	//Este metodo es para elementos con id NAME
	public boolean SelectDropDownTEXTByID(WebDriver driver, String idElemento, String SeleccionarElementoDropdown )  {

		try{
			Select selection = new Select(driver.findElement(By.id(idElemento)));
			selection.selectByVisibleText(SeleccionarElementoDropdown);

		}catch(Exception Obj_Excepcion)
		{
			// Registra en LOG el error generado al encontrar el elemento definido en la variable Str_Elemento
			Str_Error="Error 00039: No se pudo seleccionar el elemento del dropdown" + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);
			ResultFail();
			return false;
		}
		//Mensaje por consola indicando que se ha hecho clic en el elemento
		System.out.println("Informacion: Elemento seleccionado correctamente");
		return true;
	}
}