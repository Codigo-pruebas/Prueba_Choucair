package com.actions;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.codigo.Cls_Cross_Browsing;
import com.codigo.Cls_Log_Ejecucion;
import com.data.AdminProperties;

public class CP_Empleos {

	Cls_Cross_Browsing Obj_Cross_Browsing ;
	Cls_Log_Ejecucion Obj_Log_Ejecucion;
	public static String Str_Error;	
	Actions actions;
	WebDriver Obj_Driver;

	//Variables
	String url = "https://www.choucairtesting.com/";
	String clic_Empleos = "//*[@id=\"menu-item-550\"]/a";
	String campo_PalabraClave = "//*[@id=\"search_keywords\"]";
	String campo_Localizacion = "//*[@id=\"search_location\"]";
	String clic_Buscar = "//*[@id=\"content\"]/div/div/div/div/div/section[8]/div/div/div/div/div/div[3]/div/div/div/form/div[1]/div[4]/input";
	
	
	public void cargarDriver(){
		
		Obj_Cross_Browsing = new Cls_Cross_Browsing();
		Obj_Cross_Browsing.Eleccion_Browser(AdminProperties.BROWSER,AdminProperties.LOG_OPTION);
		Obj_Driver = Obj_Cross_Browsing.get_Obj_Driver();
	}

	public void ingresarAplicacion(){
		try{
			// Solo cambio URL
			Obj_Cross_Browsing.Abrir_Website(Obj_Driver, url);			
			actions = new Actions(Obj_Cross_Browsing.get_Obj_Driver());
			actions.className = this.getClass().getSimpleName();
//			Obj_Driver.findElement(By.id(str_Continue)).click();
		}catch(Exception Obj_Excepcion)
		{
			Str_Error = "Error (00007): Error inicializando el navegador , " + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);	
		}
	}

	public void pruebaChoucair(String analista, String locali ) {
		
		actions.esperarSegundos(5);
		actions.clickByXpath(clic_Empleos, "Empleos");
		actions.esperarSegundos(5);
		actions.TypeByXpath(campo_PalabraClave, analista , "Palabra Clave");
		actions.esperarSegundos(5);
		actions.TypeByXpath(campo_Localizacion, locali, "Localización");
		actions.esperarSegundos(5);
		actions.clickByXpath(clic_Buscar, "Buscar Empleo");
		actions.esperarSegundos(10);
		
	}
	
	
	public void Cerrar_Pagina (){
		try{
			Obj_Driver.quit();
		}
		catch(Exception Obj_Excepcion)
		{
			Str_Error = "Error (000013): Error en cerrar pagina, " + Obj_Excepcion.getMessage();
			System.out.println(Str_Error);	
		}
	}

	public void salir() throws InterruptedException{
		actions.esperarSegundos(10);
		Obj_Driver.quit();
	}
	
}
