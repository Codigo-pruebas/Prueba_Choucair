package com.test;

import com.run.CP_Empleos_Run;

public class Test_Ejerci {

	public static void main(String[] args) {

			
		CP_Empleos_Run run = new CP_Empleos_Run();
		run.Ejecutar_Caso();
	}
}
